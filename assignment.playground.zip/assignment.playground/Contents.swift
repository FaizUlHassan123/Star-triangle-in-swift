import UIKit

var str = "Hello, playground"
func star()
{
    //left print star working
    for i in 1...5{
        for _ in 1...i{
            print("*",terminator:"")
        }
        print(" ")
    }
    
}

func star2(){
    for i in 1...5{
        for _ in stride(from: 5, to: i, by: -1) {
            print(" ",terminator:"")
        }
        for _ in 1...i{
            print("*",terminator:"")
        }
        print("")
    }
}

func star3()
{
    for index in stride(from: 6, to: 1, by: -1) {
        for _ in 2...index{
            print("*", terminator:"")
        }
        print("")
    }
}



func star4(){
    for index in stride(from: 6 , to: 1 , by: -1)
    {
        for _ in stride(from: 6 , to: index , by: -1 ) {
            print(" " , terminator:"")
        }
        for _ in 2...index{
            print("*", terminator:"")
        }
        
        print("")
    }
}


star()
//star2()
//star3()
//star4()


